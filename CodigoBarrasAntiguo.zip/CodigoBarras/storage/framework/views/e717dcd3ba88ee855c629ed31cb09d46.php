<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p>  
        <?php for($i = 0; $i < (4*$cuenta->plnniv); $i++): ?>
            &nbsp;
        <?php endfor; ?> 
        Código: <?php echo e($cuenta->plncod); ?>, Nivel: <?php echo e($cuenta->plnniv); ?>

    </p>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Ocultar todas las sublistas al principio
            $('.sub-cuentas').hide();

            // Mostrar u ocultar la lista secundaria cuando se hace clic en el botón
            $('.toggle').click(function() {
                $(this).next('.sub-cuentas').toggle();
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partes.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/modulos/contabilidad/planCuentas.blade.php ENDPATH**/ ?>