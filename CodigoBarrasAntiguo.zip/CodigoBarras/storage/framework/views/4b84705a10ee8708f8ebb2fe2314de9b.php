<?php $__env->startSection('styles'); ?>
    <style>
        .global-container{
            height:100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="global-container">
        <div class="card login-form">
            <div class="card-body">
                <h3 class="card-title text-center">Obtener Rut del usuario</h3>
                <div class="card-text">
                <?php if(isset($errors) && count($errors) > 0): ?>
                    <div class = "alert alert-danger">
                        <ul class = "list-unstyled mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                    <form action = "/formularioObtenerRut" method = "POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="usuarioCorreo">Tipo de identificacion</label>
                            <input type="text" class="form-control form-control-sm" name = "tipoIdentificacion" id="tipoIdentificacion">
                        </div>
                        <div class="form-group">
                            <label for="usuarioCorreo">Identificacion</label>
                            <input type="number" class="form-control form-control-sm" name = "identificacion" id="identificacion">
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Registrar</button>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partes.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/obtenerRut.blade.php ENDPATH**/ ?>