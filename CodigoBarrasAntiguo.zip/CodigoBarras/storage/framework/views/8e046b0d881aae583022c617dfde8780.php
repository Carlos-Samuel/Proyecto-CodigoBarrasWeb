<?php $__env->startSection('styles'); ?>
<style>
    .date-input {
        font-size: 1.5em;
        padding: 10px;
        width: 100%;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="global-container">
        <h1>Consolidado de ventas por medio de pago</h1>
        <p>Las fechas limite son las escaneadas, y los datos consolidades son solo los de estado cerrado que no han sido anulados</p>
        <hr>
        <div class="row">
            <div class="col-md-6">
                <h3>Fecha inicio: </h3>
                <input type="date" id="fInicio" class="date-input" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>">
            </div>
            <div class="col-md-6">
                <h3>Fecha final: </h3>
                <input type="date" id="fFinal" class="date-input" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>">
            </div>
        </div>
        <hr>
        <br>
        <table id="tablaInforme1" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>Metodo de Pago</th>
                    <th>Total</th>
                </tr>
            </thead>
        </table>
        <br>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            function reloadTable() {
                $('#tablaInforme1').DataTable().ajax.reload();
            }

            function validateDates() {
                let fInicio = $('#fInicio').val();
                let fFinal = $('#fFinal').val();

                if (fInicio && fFinal) {
                    if (fInicio > fFinal) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error de fecha',
                            text: 'La fecha de inicio no puede ser posterior a la fecha final.',
                        });
                        return false;
                    }
                }
                return true;
            }

            $('#fInicio, #fFinal').on('change', function() {
                if (validateDates()) {
                    reloadTable();
                }
            });

            $('#tablaInforme1').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": "<?php echo e(route('informes.dataTableInforme1')); ?>",
                    "data": function (d) {
                        d.fInicio = $('#fInicio').val();
                        d.fFinal = $('#fFinal').val();
                    }
                },
                "columns": [
                    { "data": "metodo" },
                    { "data": "total" }
                ],
                "language": {
                    "url": "<?php echo e(asset('js/Spanish.json')); ?>"
                },
                "dom": 'Bfrtip', 
                "buttons": [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partes.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/csmedina/Documents/Proyecto-CodigoBarras/CodigoBarras/resources/views/informes/index1.blade.php ENDPATH**/ ?>