<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Métodos de Pago</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success mt-2">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <br>
    <a href="<?php echo e(route('metodos_de_pago.create')); ?>" class="btn btn-primary">Crear Método de Pago</a>
    <br>
    <br>
    <table class="table mt-2">
        <thead>
            <tr>
                <th>ID</th>
                <th>Descripción</th>
                <th>Cuenta</th>
                <th>Imagen</th>
                <th>Activo</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $metodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($metodo->idMetodos_de_pago); ?></td>
                <td><?php echo e($metodo->Descripcion); ?></td>
                <td><?php echo e($metodo->Cuenta); ?></td>
                <td>
                    <img src="<?php echo e(asset('storage/' . $metodo->Imagen)); ?>" alt="Imagen del método de pago" style="width: 50px; height: 50px; object-fit: cover;">
                </td>
                <td><?php echo e($metodo->Activo ? 'Sí' : 'No'); ?></td>
                <td>
                    <a href="<?php echo e(route('metodos_de_pago.show', $metodo->idMetodos_de_pago)); ?>" class="btn btn-info">Ver</a>
                    <a href="<?php echo e(route('metodos_de_pago.edit', $metodo->idMetodos_de_pago)); ?>" class="btn btn-warning">Editar</a>
                    <!--
                    <form action="<?php echo e(route('metodos_de_pago.destroy', $metodo->idMetodos_de_pago)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Eliminar</button>
                    </form>
                    -->
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <br>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#tablaUsuarios').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": "<?php echo e(route('usuarios.dataTable')); ?>",
                "columns": [
                    { "data": "idUsuarios" },
                    { "data": "cedula" },
                    { "data": "nombres" },
                    { "data": "apellidos" },
                    { "data": "activar" },
                    { "data": "editar" },
                    { "data": "permisos" }
                ],
                "createdRow": function(row, data, dataIndex) {
                    if (data.plncod%2 == 0) {
                        $(row).addClass('row-highlight');
                    }
                },
                "language": {
                    "url": "<?php echo e(asset('js/Spanish.json')); ?>"
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partes.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/csmedina/Documents/Proyecto-CodigoBarras/CodigoBarras/resources/views/metodos_de_pago/index.blade.php ENDPATH**/ ?>