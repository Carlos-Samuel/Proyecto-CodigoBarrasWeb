<?php $__env->startSection('styles'); ?>
    <style>
        .form-check-label {
            font-size: 1.2em;
        }
        .form-check-input {
            transform: scale(1.5);
            margin-right: 10px;
        }
        .card {
            padding: 20px;
            border-radius: 10px;
        }
        .card-footer {
            background-color: #f8f9fa;
            border-top: 1px solid #e9ecef;
            padding: 20px;
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
        }
        .btn-primary {
            font-size: 1.1em;
            padding: 10px 20px;
        }
    </style>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="mb-4">Modificar Permisos para <?php echo e($user->nombres); ?> <?php echo e($user->apellidos); ?></h1>
    <form action="<?php echo e(route('usuarios.updatePermissions', $user->idUsuarios)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="card shadow">
            <div class="card-body">
                <div class="form-group">
                    <?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check form-check-lg">
                        <input type="checkbox" class="form-check-input" name="permisos[]" value="<?php echo e($permiso->idPermisos); ?>"
                            <?php echo e($user->permisos->contains($permiso->idPermisos) ? 'checked' : ''); ?>>
                        <label class="form-check-label"><?php echo e($permiso->Descripcion); ?></label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="card-footer text-right">
                <button type="submit" class="btn btn-primary">Actualizar Permisos</button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('partes.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partes.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/csmedina/Documents/Proyecto-CodigoBarras/CodigoBarras/resources/views/usuarios/permissions.blade.php ENDPATH**/ ?>