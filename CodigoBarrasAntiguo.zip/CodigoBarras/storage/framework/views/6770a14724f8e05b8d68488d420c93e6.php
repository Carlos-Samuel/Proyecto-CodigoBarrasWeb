<?php $__env->startSection('styles'); ?>
    <style>
        .global-container{
            height:100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        #tablaTickets thead {
            background-color: #82c6ff;
            color: #ffffff;
        }

        #tablaTickets td, #tablaTickets th {
            padding: 8px; 
        }

        .row-highlight td {
            background-color: #ffcccc !important;
        }

        #tablaTickets tr:nth-child(even){
            background-color: #f2f2f2;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="global-container">
        <?php if(!empty($mensaje)): ?>
        <div class="card login-form">
            <div class="card-body">
                <h3 class="card-title text-center"></h3>
                <div class="card-text">
                    <div class="alert alert-warning">
                        <?php echo e($mensaje); ?>

                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <table id="tablaTickets" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Celular</th>
                    <th>Email</th>
                    <th>Borrar</th>
                </tr>
            </thead>
        </table>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#tablaTickets').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": "<?php echo e(route('tickets.dataTable')); ?>",
                "columns": [
                    { "data": "id" },
                    { "data": "nombre_contacto" },
                    { "data": "numero_contacto" },
                    { "data": "correo_contacto" },
                    { "data": "action" }
                ],
                "createdRow": function(row, data, dataIndex) {
                    if (data.plncod%2 == 0) {
                        $(row).addClass('row-highlight');
                    }
                },
                "language": {
                    "url": "<?php echo e(asset('js/Spanish.json')); ?>"
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partes.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/csmedina/Documents/Proyecto-Contabilidad/AdminCS/resources/views/indexTickets.blade.php ENDPATH**/ ?>