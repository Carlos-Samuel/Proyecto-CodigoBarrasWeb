<?php $__env->startSection('content'); ?>
    <div class="global-container">
        
        <?php if(auth()->guard()->check()): ?>
            <p>Bienvenido a Roomies Finance <?php echo e(auth()->user()->name ?? auth()->user()->username); ?>. </p>
            <br>
            <h3><?php echo e($mensaje); ?></h3>
            <br>
            <a href = "/pagar"><button class="btn btn-success btn-block">Pagar todo</button></a>

        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
            <p>Para ver el contenido <a href="/login">inicia sesion</a></p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partes.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/csmedina/Documents/Proyecto-CodigoBarras/CodigoBarras/resources/views/index.blade.php ENDPATH**/ ?>