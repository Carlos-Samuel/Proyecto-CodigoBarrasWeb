<?php $__env->startSection('styles'); ?>
    <style>
        .global-container{
            height:100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="global-container">
        <?php if(HelperPer::checkPermisos(1)): ?>
            <!-- <p>El usuario tiene este permiso.</p> -->
        <?php else: ?>
            <!-- <p>El usuario no tiene este permiso.</p> -->
        <?php endif; ?>
        <br>
        <?php if(!empty($mensaje)): ?>
        <div class="card login-form">
            <div class="card-body">
                <h3 class="card-title text-center"></h3>
                <div class="card-text">
                    <div class="alert alert-warning">
                        <?php echo e($mensaje); ?>

                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('partes.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/csmedina/Documents/Proyecto-CodigoBarras/CodigoBarras/resources/views/dashboard.blade.php ENDPATH**/ ?>