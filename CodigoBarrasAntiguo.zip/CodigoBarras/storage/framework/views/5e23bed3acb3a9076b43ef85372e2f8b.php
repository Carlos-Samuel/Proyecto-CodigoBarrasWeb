<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Detalles del Método de Pago</h1>
    <table class="table">
        <tr>
            <th>ID</th>
            <td><?php echo e($metodo->idMetodos_de_pago); ?></td>
        </tr>
        <tr>
            <th>Descripción</th>
            <td><?php echo e($metodo->Descripcion); ?></td>
        </tr>
        <tr>
            <th>Cuenta</th>
            <td><?php echo e($metodo->Cuenta); ?></td>
        </tr>
        <tr>
            <th>Imagen</th>
            <td>
                <?php if($metodo->Imagen): ?>
                    <img src="<?php echo e(asset('storage/' . $metodo->Imagen)); ?>" alt="<?php echo e($metodo->Descripcion); ?>" class="img-thumbnail" style="max-width: 200px;">
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <th>Activo</th>
            <td><?php echo e($metodo->Activo ? 'Sí' : 'No'); ?></td>
        </tr>
    </table>
    <a href="<?php echo e(route('metodos_de_pago.index')); ?>" class="btn btn-secondary">Volver</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partes.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/csmedina/Documents/Proyecto-CodigoBarras/CodigoBarras/resources/views/metodos_de_pago/show.blade.php ENDPATH**/ ?>