<?php $__env->startSection('styles'); ?>
    <style>
        .global-container{
            height:100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        #tablaTickets thead {
            background-color: #82c6ff;
            color: #ffffff;
        }

        #tablaTickets td, #tablaTickets th {
            padding: 8px; 
        }

        .row-highlight td {
            background-color: #ffcccc !important;
        }

        #tablaTickets tr:nth-child(even){
            background-color: #f2f2f2;
        }

        .global-container {
            display: flex;
            flex-direction: column;
        }

        .crear-btn-container {
            display: flex;        /* Utiliza flexbox para alinear los elementos dentro */
            justify-content: flex-end; /* Alinea los elementos a la derecha */
            margin-bottom: 20px; /* Espacio entre el botón y el mensaje o la tabla */
        }

        .table-container {
            margin-top: 20px; /* Espacio entre el mensaje y la tabla, si el mensaje está presente */
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="global-container">
    <!-- Botón Crear arriba -->
    <div class="crear-btn-container">
        <a href="<?php echo e(route('terceros.crear')); ?>" class="btn btn-primary">Registrar Tercero</a>
    </div>

    <!-- Mensaje condicional -->
    <?php if(!empty($mensaje)): ?>
    <div class="card login-form">
        <div class="card-body">
            <h3 class="card-title text-center"></h3>
            <div class="card-text">
                <div class="alert alert-warning">
                    <?php echo e($mensaje); ?>

                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Tabla debajo -->
    <div class="table-container">
        <table id="tablaTickets" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Celular</th>
                    <th>Email</th>
                    <th>Borrar</th>
                </tr>
            </thead>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#tablaTickets').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": "<?php echo e(route('terceros.dataTable')); ?>",
                "columns": [
                    { "data": "id" },
                    { "data": "numero_identificacion" },
                    { "data": "primer_nombre" },
                    { "data": "email" },
                    { "data": "action" }
                ],
                "createdRow": function(row, data, dataIndex) {
                    if (data.plncod%2 == 0) {
                        $(row).addClass('row-highlight');
                    }
                },
                "language": {
                    "url": "<?php echo e(asset('js/Spanish.json')); ?>"
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partes.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/csmedina/Documents/Proyecto-Contabilidad/AdminCS/resources/views/indexTerceros.blade.php ENDPATH**/ ?>