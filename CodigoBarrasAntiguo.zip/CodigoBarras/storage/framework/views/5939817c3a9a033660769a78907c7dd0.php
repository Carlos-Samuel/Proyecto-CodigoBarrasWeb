<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Editar Usuario</h1>
    <div class="card-text">
        <?php if(isset($errors) && count($errors) > 0): ?>
            <div class = "alert alert-danger">
                <ul class = "list-unstyled mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>                
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </ul>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('usuarios.update', $user->idUsuarios)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="cedula">Cédula</label>
                <input type="text" class="form-control form-control-sm" name="cedula" id="cedula" value="<?php echo e(old('cedula', $user->cedula)); ?>" readonly>
                <?php if($errors->has('cedula')): ?>
                    <span class="text-danger"><?php echo e($errors->first('cedula')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="nombre">Nombres</label>
                <input type="text" class="form-control form-control-sm" name="nombres" id="nombres" value="<?php echo e(old('nombres', $user->nombres)); ?>">
                <?php if($errors->has('nombres')): ?>
                    <span class="text-danger"><?php echo e($errors->first('nombres')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="apellido">Apellidos</label>
                <input type="text" class="form-control form-control-sm" name="apellidos" id="apellidos" value="<?php echo e(old('apellidos', $user->apellidos)); ?>">
                <?php if($errors->has('apellidos')): ?>
                    <span class="text-danger"><?php echo e($errors->first('apellidos')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="correo">Email</label>
                <input type="email" class="form-control form-control-sm" name="correo" id="correo" value="<?php echo e(old('correo', $user->correo)); ?>">
                <?php if($errors->has('correo')): ?>
                    <span class="text-danger"><?php echo e($errors->first('correo')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="password">Contraseña</label>
                <input type="password" class="form-control form-control-sm" name="password" id="password">
                <?php if($errors->has('password')): ?>
                    <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="password_confirmation">Confirmar Contraseña</label>
                <input type="password" class="form-control form-control-sm" name="password_confirmation" id="password_confirmation">
                <?php if($errors->has('password_confirmation')): ?>
                    <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
                <?php endif; ?>
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partes.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/csmedina/Documents/Proyecto-CodigoBarras/CodigoBarras/resources/views/usuarios/edit.blade.php ENDPATH**/ ?>