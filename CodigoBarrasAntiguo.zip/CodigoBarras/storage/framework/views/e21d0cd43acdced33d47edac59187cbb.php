<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Editar Método de Pago</h1>
    <form action="<?php echo e(route('metodos_de_pago.update', $metodo->idMetodos_de_pago)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="Descripcion" class="form-label">Descripción</label>
            <input type="text" class="form-control" id="Descripcion" name="Descripcion" value="<?php echo e($metodo->Descripcion); ?>" required>
        </div>
        <div class="mb-3">
            <label for="Cuenta" class="form-label">Cuenta</label>
            <input type="text" class="form-control" id="Cuenta" name="Cuenta" value="<?php echo e($metodo->Cuenta); ?>" required>
        </div>
        <div class="mb-3">
            <label for="Imagen" class="form-label">Imagen</label>
            <?php if($metodo->Imagen): ?>
                <img src="<?php echo e(asset('storage/' . $metodo->Imagen)); ?>" alt="<?php echo e($metodo->Descripcion); ?>" class="img-thumbnail mb-2" style="max-width: 200px;">
            <?php endif; ?>
            <input type="file" class="form-control" id="Imagen" name="Imagen">
        </div>
        <div class="mb-3">
            <label for="Activo" class="form-label">Activo</label>
            <select class="form-control" id="Activo" name="Activo" required>
                <option value="1" <?php echo e($metodo->Activo ? 'selected' : ''); ?>>Sí</option>
                <option value="0" <?php echo e(!$metodo->Activo ? 'selected' : ''); ?>>No</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partes.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/csmedina/Documents/Proyecto-CodigoBarras/CodigoBarras/resources/views/metodos_de_pago/edit.blade.php ENDPATH**/ ?>