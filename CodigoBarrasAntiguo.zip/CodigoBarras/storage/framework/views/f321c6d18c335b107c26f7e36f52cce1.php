<?php $__env->startSection('styles'); ?>
    <style>
        label {
            display: block;
            margin-top: 10px;
        }

        .select2-container {
            width: 100% !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="global-container">
    
    <?php if(!empty($mensaje)): ?>
    <div class="card login-form">
        <div class="card-body">
            <h3 class="card-title text-center"></h3>
            <div class="card-text">
                <div class="alert alert-warning">
                    <?php echo e($mensaje); ?>

                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(isset($tercero) ? route('terceros.update', $tercero->id) : route('terceros.guardar')); ?>">
        <?php echo csrf_field(); ?>
        <?php if(isset($tercero)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <label for="numero_identificacion">Número de Identificación:</label>
        <input type="text" id="numero_identificacion" name="numero_identificacion" value="<?php echo e(old('numero_identificacion', $tercero->numero_identificacion ?? '')); ?>">

        <label for="tipo_identificacion_id">Tipo de Identificación:</label>
        <select id="tipo_identificacion_id" name="tipo_identificacion_id" class="select2">
            <?php $__currentLoopData = $tiposDocumento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoDocumento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($tipoDocumento->id); ?>" <?php echo e((old('tipo_identificacion_id', $tercero->tipo_identificacion_id ?? '') == $tipoDocumento->id) ? 'selected' : ''); ?>>
                    <?php echo e($tipoDocumento->sigla); ?> - <?php echo e($tipoDocumento->nombre); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="digito_verificacion">Dígito de Verificación:</label>
        <input type="text" id="digito_verificacion" name="digito_verificacion" value="<?php echo e(old('digito_verificacion', $tercero->digito_verificacion ?? '')); ?>">

        <label for="primer_nombre">Primer Nombre:</label>
        <input type="text" id="primer_nombre" name="primer_nombre" value="<?php echo e(old('primer_nombre', $tercero->primer_nombre ?? '')); ?>">

        <label for="segundo_nombre">Segundo Nombre:</label>
        <input type="text" id="segundo_nombre" name="segundo_nombre" value="<?php echo e(old('segundo_nombre', $tercero->segundo_nombre ?? '')); ?>">

        <label for="primer_apellido">Primer Apellido:</label>
        <input type="text" id="primer_apellido" name="primer_apellido" value="<?php echo e(old('primer_apellido', $tercero->primer_apellido ?? '')); ?>">

        <label for="segundo_apellido">Segundo Apellido:</label>
        <input type="text" id="segundo_apellido" name="segundo_apellido" value="<?php echo e(old('segundo_apellido', $tercero->segundo_apellido ?? '')); ?>">

        <label for="razon_social">Razón Social:</label>
        <input type="text" id="razon_social" name="razon_social" value="<?php echo e(old('razon_social', $tercero->razon_social ?? '')); ?>">

        <label for="direccion">Dirección:</label>
        <input type="text" id="direccion" name="direccion" value="<?php echo e(old('direccion', $tercero->direccion ?? '')); ?>">

        <label for="telefono">Teléfono:</label>
        <input type="text" id="telefono" name="telefono" value="<?php echo e(old('telefono', $tercero->telefono ?? '')); ?>">

        <label for="fax">Fax:</label>
        <input type="text" id="fax" name="fax" value="<?php echo e(old('fax', $tercero->fax ?? '')); ?>">

        <label for="celular">Celular:</label>
        <input type="text" id="celular" name="celular" value="<?php echo e(old('celular', $tercero->celular ?? '')); ?>">

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo e(old('email', $tercero->email ?? '')); ?>">

        <label for="sitio_web">Sitio Web:</label>
        <input type="text" id="sitio_web" name="sitio_web" value="<?php echo e(old('sitio_web', $tercero->sitio_web ?? '')); ?>">

        <label for="pais_id">País:</label>
        <select id="pais_id" name="pais_id" class="select2">
            <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pais->codigo_iso_numeric); ?>" <?php echo e((old('pais_id', $tercero->pais_id ?? '') == $pais->codigo_iso_numeric) ? 'selected' : ''); ?>>
                    <?php echo e($pais->nombre); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="ciudad">Ciudad:</label>
        <select id="ciudad" name="ciudad" class="select2">
            <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($ciudad->codigo); ?>" <?php echo e((old('ciudad', $tercero->ciudad ?? '') == $ciudad->codigo) ? 'selected' : ''); ?>>
                    <?php echo e($ciudad->nombre); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="regimen_id">Régimen:</label>
        <select id="regimen_id" name="regimen_id" class="select2">
            <?php $__currentLoopData = $regimenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regimen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($regimen->id); ?>" <?php echo e((old('regimen_id', $tercero->regimen_id ?? '') == $regimen->id) ? 'selected' : ''); ?>>
                    <?php echo e($regimen->descripcion); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="tipo_persona_id">Tipo de Persona:</label>
        <select id="tipo_persona_id" name="tipo_persona_id" class="select2">
            <?php $__currentLoopData = $tiposPersona; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoPersona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($tipoPersona->id); ?>" <?php echo e((old('tipo_persona_id', $tercero->tipo_persona_id ?? '') == $tipoPersona->id) ? 'selected' : ''); ?>>
                    <?php echo e($tipoPersona->descripcion); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        
        <label for="tipo_tercero">Tipo de Tercero:</label>
        <select id="tipo_tercero" name="tipo_tercero" class="select2">
            <option value="1" <?php echo e((old('tipo_tercero', $tercero->tipo_tercero ?? '') == 1) ? 'selected' : ''); ?>>Cliente</option>
            <option value="2" <?php echo e((old('tipo_tercero', $tercero->tipo_tercero ?? '') == 2) ? 'selected' : ''); ?>>Proveedor</option>
            <option value="3" <?php echo e((old('tipo_tercero', $tercero->tipo_tercero ?? '') == 3) ? 'selected' : ''); ?>>Empleado</option>
        </select>

        <br>
        <br>
        <button type="submit">Enviar</button>
    </form>

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.select2').select2();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partes.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/csmedina/Documents/Proyecto-Contabilidad/AdminCS/resources/views/modulos/terceros/crearTercero.blade.php ENDPATH**/ ?>