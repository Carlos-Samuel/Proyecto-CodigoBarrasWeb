<?php $__env->startSection('styles'); ?>
	<style>
		.global-container{
			height:100%;
			display: flex;
			align-items: center;
			justify-content: center;
		}
	</style>
<?php $__env->stopSection(); ?>


	<div class="global-container">
		<div class="card login-form">
			<div class="card-body">
				<h3 class="card-title text-center">INICIO DE SESION A NOMBRE EMPRESA</h3>
				<div class="card-text">
				<?php if(isset($errors) && count($errors) > 0): ?>
    <div class = "alert alert-danger">
        <ul class = "list-unstyled mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php
 //echo bcrypt("santiago");
?>
					<form action = "/login" method = "POST">
						<?php echo csrf_field(); ?>
						<div class="form-group">
							<label for="usuarioCorreo">Correo</label>
							<input type="text" class="form-control form-control-sm" name = "email" id="email">
						</div>
						<div class="form-group">
							<label for="contraseña">Contraseña</label>
							
							<input type="password" class="form-control form-control-sm" name = "password" id="password">
						</div>
						<button type="submit" class="btn btn-primary btn-block">Iniciar sesión</button>
					</form>
					<a href = "/register"><button class="btn btn-success btn-block">Registrar Usuario</button></a>
				</div>
			</div>
		</div>
	</div>
	

<?php echo $__env->make('plantillaVanila.vanilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/csmedina/Documents/Proyecto-Contabilidad/AdminCS/resources/views/login.blade.php ENDPATH**/ ?>